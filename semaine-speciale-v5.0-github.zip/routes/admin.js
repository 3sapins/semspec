const express = require('express');
const router = express.Router();
const multer = require('multer');
const csv = require('csv-parse');
const bcrypt = require('bcrypt');
const { query, transaction } = require('../config/database');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');
const fs = require('fs').promises;

// Configuration upload
const upload = multer({ 
    dest: 'uploads/',
    limits: { fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10485760 } // 10MB par défaut
});

// Protection: toutes les routes admin nécessitent authentification + rôle admin
router.use(authMiddleware, adminMiddleware);

/**
 * POST /api/admin/import/salles
 * Import CSV des salles
 */
router.post('/import/salles', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'Fichier CSV requis'
            });
        }

        const fileContent = await fs.readFile(req.file.path, 'utf-8');
        const records = [];

        // Parse CSV
        const parser = csv.parse(fileContent, {
            columns: true,
            skip_empty_lines: true,
            trim: true
        });

        for await (const record of parser) {
            records.push(record);
        }

        // Suppression du fichier temporaire
        await fs.unlink(req.file.path);

        let imported = 0;
        let errors = [];

        // Import des salles
        for (const record of records) {
            try {
                const disponible = record.disponible === 'TRUE' || record.disponible === '1' || record.disponible === 'true';
                
                await query(
                    `INSERT INTO salles (nom, capacite, type_salle, equipement, batiment, etage, disponible) 
                     VALUES (?, ?, ?, ?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE 
                     capacite = VALUES(capacite),
                     type_salle = VALUES(type_salle),
                     equipement = VALUES(equipement),
                     batiment = VALUES(batiment),
                     etage = VALUES(etage),
                     disponible = VALUES(disponible)`,
                    [
                        record.nom,
                        parseInt(record.capacite) || 25,
                        record.type_salle || null,
                        record.equipement || null,
                        record.batiment || null,
                        record.etage || null,
                        disponible
                    ]
                );
                imported++;
            } catch (error) {
                errors.push({ salle: record.nom, error: error.message });
            }
        }

        // Log de l'action
        await query(
            'INSERT INTO historique (utilisateur_id, action, details) VALUES (?, ?, ?)',
            [req.user.id, 'IMPORT_SALLES', `${imported} salles importées`]
        );

        res.json({
            success: true,
            message: `${imported} salles importées avec succès`,
            data: {
                imported,
                total: records.length,
                errors
            }
        });

    } catch (error) {
        console.error('Erreur import salles:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de l\'import des salles',
            error: error.message
        });
    }
});

/**
 * POST /api/admin/import/enseignants
 * Import CSV des enseignants
 */
router.post('/import/enseignants', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'Fichier CSV requis'
            });
        }

        const fileContent = await fs.readFile(req.file.path, 'utf-8');
        const records = [];

        const parser = csv.parse(fileContent, {
            columns: true,
            skip_empty_lines: true,
            trim: true
        });

        for await (const record of parser) {
            records.push(record);
        }

        await fs.unlink(req.file.path);

        let imported = 0;
        let errors = [];

        // Mot de passe par défaut pour les nouveaux comptes
        const defaultPassword = await bcrypt.hash('SemaineSpeciale2026', 10);

        for (const record of records) {
            try {
                await query(
                    `INSERT INTO utilisateurs (acronyme, nom, prenom, email, mot_de_passe, role) 
                     VALUES (?, ?, ?, ?, ?, 'enseignant')
                     ON DUPLICATE KEY UPDATE 
                     nom = VALUES(nom),
                     prenom = VALUES(prenom),
                     email = VALUES(email)`,
                    [
                        record.acronyme.toUpperCase(),
                        record.nom,
                        record.prenom,
                        record.email || null,
                        defaultPassword
                    ]
                );
                imported++;
            } catch (error) {
                errors.push({ acronyme: record.acronyme, error: error.message });
            }
        }

        await query(
            'INSERT INTO historique (utilisateur_id, action, details) VALUES (?, ?, ?)',
            [req.user.id, 'IMPORT_ENSEIGNANTS', `${imported} enseignants importés`]
        );

        res.json({
            success: true,
            message: `${imported} enseignants importés avec succès`,
            data: {
                imported,
                total: records.length,
                errors,
                info: 'Mot de passe par défaut: SemaineSpeciale2026'
            }
        });

    } catch (error) {
        console.error('Erreur import enseignants:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de l\'import des enseignants'
        });
    }
});

/**
 * POST /api/admin/import/eleves
 * Import CSV des élèves
 */
router.post('/import/eleves', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'Fichier CSV requis'
            });
        }

        const fileContent = await fs.readFile(req.file.path, 'utf-8');
        const records = [];

        const parser = csv.parse(fileContent, {
            columns: true,
            skip_empty_lines: true,
            trim: true
        });

        for await (const record of parser) {
            records.push(record);
        }

        await fs.unlink(req.file.path);

        let imported = 0;
        let errors = [];

        // Mot de passe par défaut pour les élèves
        const defaultPassword = await bcrypt.hash('eleve2026', 10);

        for (const record of records) {
            try {
                // Récupération de l'ID de la classe
                const classes = await query('SELECT id FROM classes WHERE nom = ?', [record.classe]);
                
                if (classes.length === 0) {
                    errors.push({ 
                        eleve: `${record.prenom} ${record.nom}`, 
                        error: `Classe ${record.classe} non trouvée` 
                    });
                    continue;
                }

                const classeId = classes[0].id;

                // Génération d'un acronyme pour l'élève (3 premières lettres du nom)
                const acronyme = `${record.nom.substring(0, 3).toUpperCase()}${record.prenom.substring(0, 2).toUpperCase()}`;

                // Création du compte utilisateur
                const result = await query(
                    `INSERT INTO utilisateurs (acronyme, nom, prenom, mot_de_passe, role) 
                     VALUES (?, ?, ?, ?, 'eleve')
                     ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)`,
                    [acronyme, record.nom, record.prenom, defaultPassword]
                );

                const userId = result.insertId;

                // Liaison avec la classe
                await query(
                    `INSERT INTO eleves (utilisateur_id, classe_id, numero_eleve) 
                     VALUES (?, ?, ?)
                     ON DUPLICATE KEY UPDATE numero_eleve = VALUES(numero_eleve)`,
                    [userId, classeId, record.numero_eleve || null]
                );

                imported++;
            } catch (error) {
                errors.push({ 
                    eleve: `${record.prenom} ${record.nom}`, 
                    error: error.message 
                });
            }
        }

        await query(
            'INSERT INTO historique (utilisateur_id, action, details) VALUES (?, ?, ?)',
            [req.user.id, 'IMPORT_ELEVES', `${imported} élèves importés`]
        );

        res.json({
            success: true,
            message: `${imported} élèves importés avec succès`,
            data: {
                imported,
                total: records.length,
                errors,
                info: 'Mot de passe par défaut: eleve2026'
            }
        });

    } catch (error) {
        console.error('Erreur import élèves:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de l\'import des élèves'
        });
    }
});

/**
 * GET /api/admin/stats
 * Statistiques globales
 */
router.get('/stats', async (req, res) => {
    try {
        const stats = {};

        // Nombre total d'utilisateurs par rôle
        const users = await query(`
            SELECT role, COUNT(*) as count 
            FROM utilisateurs 
            WHERE actif = TRUE 
            GROUP BY role
        `);
        stats.utilisateurs = users;

        // Nombre de salles
        const salles = await query('SELECT COUNT(*) as count FROM salles WHERE disponible = TRUE');
        stats.salles = salles[0].count;

        // Nombre de classes
        const classes = await query('SELECT COUNT(*) as count FROM classes');
        stats.classes = classes[0].count;

        // Nombre d'ateliers par statut
        const ateliers = await query(`
            SELECT statut, COUNT(*) as count 
            FROM ateliers 
            GROUP BY statut
        `);
        stats.ateliers = ateliers;

        // Budget total
        const budget = await query(`
            SELECT SUM(budget_max) as total 
            FROM ateliers 
            WHERE statut = 'valide'
        `);
        stats.budget_total = budget[0].total || 0;

        // Budget maximum configuré
        const budgetMax = await query(`
            SELECT valeur FROM configuration WHERE cle = 'budget_max_global'
        `);
        stats.budget_max = parseFloat(budgetMax[0]?.valeur || 10000);

        // Nombre d'inscriptions
        const inscriptions = await query(`
            SELECT statut, COUNT(*) as count 
            FROM inscriptions 
            GROUP BY statut
        `);
        stats.inscriptions = inscriptions;

        res.json({
            success: true,
            data: stats
        });

    } catch (error) {
        console.error('Erreur stats:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la récupération des statistiques'
        });
    }
});

/**
 * GET /api/admin/configuration
 * Récupération de la configuration
 */
router.get('/configuration', async (req, res) => {
    try {
        const config = await query('SELECT * FROM configuration');
        
        const configObj = {};
        config.forEach(item => {
            let value = item.valeur;
            
            // Conversion selon le type
            if (item.type === 'number') value = parseFloat(value);
            else if (item.type === 'boolean') value = value === 'true' || value === '1';
            
            configObj[item.cle] = {
                valeur: value,
                description: item.description,
                type: item.type
            };
        });

        res.json({
            success: true,
            data: configObj
        });

    } catch (error) {
        console.error('Erreur configuration:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la récupération de la configuration'
        });
    }
});

/**
 * PUT /api/admin/configuration/:key
 * Modification d'une valeur de configuration
 */
router.put('/configuration/:key', async (req, res) => {
    try {
        const { key } = req.params;
        const { valeur } = req.body;

        await query(
            'UPDATE configuration SET valeur = ? WHERE cle = ?',
            [valeur.toString(), key]
        );

        await query(
            'INSERT INTO historique (utilisateur_id, action, details) VALUES (?, ?, ?)',
            [req.user.id, 'UPDATE_CONFIG', `Configuration ${key} modifiée`]
        );

        res.json({
            success: true,
            message: 'Configuration mise à jour'
        });

    } catch (error) {
        console.error('Erreur update config:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la mise à jour de la configuration'
        });
    }
});

/**
 * GET /api/admin/ateliers
 * Liste de tous les ateliers (tous statuts)
 */
router.get('/ateliers', async (req, res) => {
    try {
        const { statut } = req.query;
        
        let whereClause = '';
        let params = [];
        
        if (statut) {
            whereClause = 'WHERE a.statut = ?';
            params.push(statut);
        }
        
        const ateliers = await query(`
            SELECT 
                a.*,
                u.nom as enseignant_nom,
                u.prenom as enseignant_prenom,
                COUNT(DISTINCT i.id) as nombre_inscrits,
                (a.nombre_places_max - COUNT(DISTINCT i.id)) as places_restantes
            FROM ateliers a
            LEFT JOIN utilisateurs u ON a.enseignant_acronyme = u.acronyme
            LEFT JOIN inscriptions i ON a.id = i.atelier_id AND i.statut = 'confirmee'
            ${whereClause}
            GROUP BY a.id
            ORDER BY a.date_creation DESC
        `, params);
        
        res.json({
            success: true,
            data: ateliers
        });
        
    } catch (error) {
        console.error('Erreur liste ateliers admin:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la récupération des ateliers'
        });
    }
});

/**
 * PUT /api/admin/ateliers/:id/valider
 * Valider un atelier
 */
router.put('/ateliers/:id/valider', async (req, res) => {
    try {
        const { id } = req.params;
        
        // Vérifier que l'atelier existe et est soumis
        const ateliers = await query(
            'SELECT * FROM ateliers WHERE id = ? AND statut = "soumis"',
            [id]
        );
        
        if (ateliers.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Atelier non trouvé ou non soumis'
            });
        }
        
        const atelier = ateliers[0];
        
        // Vérifier le budget total
        const budgetActuel = await query(`
            SELECT SUM(budget_max) as total 
            FROM ateliers 
            WHERE statut = 'valide'
        `);
        
        const budgetMax = await query(`
            SELECT valeur FROM configuration WHERE cle = 'budget_max_global'
        `);
        
        const budgetTotal = (budgetActuel[0]?.total || 0) + parseFloat(atelier.budget_max);
        const budgetMaxValue = parseFloat(budgetMax[0]?.valeur || 10000);
        
        if (budgetTotal > budgetMaxValue) {
            return res.status(400).json({
                success: false,
                message: `Budget dépassé ! Total serait: ${budgetTotal.toFixed(2)} CHF / ${budgetMaxValue} CHF`,
                budget_total: budgetTotal,
                budget_max: budgetMaxValue
            });
        }
        
        // Valider l'atelier
        await query(
            'UPDATE ateliers SET statut = "valide" WHERE id = ?',
            [id]
        );
        
        // Log
        await query(
            'INSERT INTO historique (utilisateur_id, action, table_cible, id_cible, details) VALUES (?, ?, ?, ?, ?)',
            [req.user.id, 'VALIDATE_ATELIER', 'ateliers', id, `Atelier "${atelier.nom}" validé`]
        );
        
        res.json({
            success: true,
            message: 'Atelier validé avec succès',
            budget_total: budgetTotal,
            budget_max: budgetMaxValue
        });
        
    } catch (error) {
        console.error('Erreur validation atelier:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la validation de l\'atelier'
        });
    }
});

/**
 * PUT /api/admin/ateliers/:id/refuser
 * Refuser un atelier
 */
router.put('/ateliers/:id/refuser', async (req, res) => {
    try {
        const { id } = req.params;
        const { commentaire } = req.body;
        
        const ateliers = await query(
            'SELECT * FROM ateliers WHERE id = ? AND statut = "soumis"',
            [id]
        );
        
        if (ateliers.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Atelier non trouvé ou non soumis'
            });
        }
        
        const atelier = ateliers[0];
        
        // Mettre à jour le statut et ajouter le commentaire dans remarques
        let remarques = atelier.remarques || '';
        if (commentaire) {
            remarques += `\n[REFUSÉ] ${commentaire}`;
        }
        
        await query(
            'UPDATE ateliers SET statut = "refuse", remarques = ? WHERE id = ?',
            [remarques, id]
        );
        
        // Log
        await query(
            'INSERT INTO historique (utilisateur_id, action, table_cible, id_cible, details) VALUES (?, ?, ?, ?, ?)',
            [req.user.id, 'REFUSE_ATELIER', 'ateliers', id, `Atelier "${atelier.nom}" refusé: ${commentaire || 'Pas de commentaire'}`]
        );
        
        res.json({
            success: true,
            message: 'Atelier refusé'
        });
        
    } catch (error) {
        console.error('Erreur refus atelier:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors du refus de l\'atelier'
        });
    }
});

/**
 * POST /api/admin/ateliers/creer
 * Créer un atelier depuis l'admin
 */
router.post('/ateliers/creer', async (req, res) => {
    try {
        const {
            nom,
            description,
            enseignant_acronyme,
            enseignant2_acronyme,
            enseignant3_acronyme,
            duree,
            nombre_places_max,
            budget_max,
            type_salle_demande,
            remarques,
            informations_eleves
        } = req.body;
        
        // Validation
        if (!nom || !enseignant_acronyme || !duree || !nombre_places_max) {
            return res.status(400).json({
                success: false,
                message: 'Nom, enseignant principal, durée et places requis'
            });
        }
        
        if (![2, 4, 6].includes(parseInt(duree))) {
            return res.status(400).json({
                success: false,
                message: 'Durée doit être 2, 4 ou 6 périodes'
            });
        }
        
        const result = await query(`
            INSERT INTO ateliers (
                nom, description, enseignant_acronyme, enseignant2_acronyme, enseignant3_acronyme,
                duree, nombre_places_max, budget_max, type_salle_demande, 
                remarques, informations_eleves, statut
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'valide')
        `, [
            nom,
            description || null,
            enseignant_acronyme,
            enseignant2_acronyme || null,
            enseignant3_acronyme || null,
            duree,
            nombre_places_max,
            budget_max || 0,
            type_salle_demande || null,
            remarques || null,
            informations_eleves || null
        ]);
        
        // Log
        await query(
            'INSERT INTO historique (utilisateur_id, action, table_cible, id_cible, details) VALUES (?, ?, ?, ?, ?)',
            [req.user.id, 'CREATE', 'ateliers', result.insertId, `Atelier "${nom}" créé par admin`]
        );
        
        res.json({
            success: true,
            message: 'Atelier créé avec succès',
            data: {
                id: result.insertId
            }
        });
        
    } catch (error) {
        console.error('Erreur création atelier admin:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la création de l\'atelier'
        });
    }
});

/**
 * PUT /api/admin/ateliers/:id/modifier
 * Modifier un atelier depuis l'admin
 */
router.put('/ateliers/:id/modifier', async (req, res) => {
    try {
        const { id } = req.params;
        const {
            nom,
            description,
            enseignant_acronyme,
            enseignant2_acronyme,
            enseignant3_acronyme,
            duree,
            nombre_places_max,
            budget_max,
            type_salle_demande,
            remarques,
            informations_eleves
        } = req.body;
        
        // Vérifier que l'atelier existe
        const ateliers = await query('SELECT * FROM ateliers WHERE id = ?', [id]);
        if (ateliers.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Atelier non trouvé'
            });
        }
        
        const atelier = ateliers[0];
        
        // Mise à jour
        await query(`
            UPDATE ateliers SET
                nom = ?,
                description = ?,
                enseignant_acronyme = ?,
                enseignant2_acronyme = ?,
                enseignant3_acronyme = ?,
                duree = ?,
                nombre_places_max = ?,
                budget_max = ?,
                type_salle_demande = ?,
                remarques = ?,
                informations_eleves = ?
            WHERE id = ?
        `, [
            nom || atelier.nom,
            description !== undefined ? description : atelier.description,
            enseignant_acronyme || atelier.enseignant_acronyme,
            enseignant2_acronyme !== undefined ? enseignant2_acronyme : atelier.enseignant2_acronyme,
            enseignant3_acronyme !== undefined ? enseignant3_acronyme : atelier.enseignant3_acronyme,
            duree || atelier.duree,
            nombre_places_max || atelier.nombre_places_max,
            budget_max !== undefined ? budget_max : atelier.budget_max,
            type_salle_demande !== undefined ? type_salle_demande : atelier.type_salle_demande,
            remarques !== undefined ? remarques : atelier.remarques,
            informations_eleves !== undefined ? informations_eleves : atelier.informations_eleves,
            id
        ]);
        
        // Log
        await query(
            'INSERT INTO historique (utilisateur_id, action, table_cible, id_cible, details) VALUES (?, ?, ?, ?, ?)',
            [req.user.id, 'UPDATE', 'ateliers', id, `Atelier "${nom || atelier.nom}" modifié par admin`]
        );
        
        res.json({
            success: true,
            message: 'Atelier modifié avec succès'
        });
        
    } catch (error) {
        console.error('Erreur modification atelier admin:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la modification de l\'atelier'
        });
    }
});

/**
 * DELETE /api/admin/ateliers/:id
 * Supprimer un atelier (admin uniquement)
 */
router.delete('/ateliers/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        const ateliers = await query('SELECT * FROM ateliers WHERE id = ?', [id]);
        
        if (ateliers.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Atelier non trouvé'
            });
        }
        
        await query('DELETE FROM ateliers WHERE id = ?', [id]);
        
        // Log
        await query(
            'INSERT INTO historique (utilisateur_id, action, table_cible, id_cible, details) VALUES (?, ?, ?, ?, ?)',
            [req.user.id, 'DELETE', 'ateliers', id, `Atelier "${ateliers[0].nom}" supprimé par admin`]
        );
        
        res.json({
            success: true,
            message: 'Atelier supprimé avec succès'
        });
        
    } catch (error) {
        console.error('Erreur suppression atelier:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la suppression de l\'atelier'
        });
    }
});

/**
 * POST /api/admin/ateliers/:id/obligatoire
 * Marquer un atelier comme obligatoire pour certaines classes
 */
router.post('/ateliers/:id/obligatoire', async (req, res) => {
    try {
        const { id } = req.params;
        const { classes } = req.body; // Array de class IDs
        
        if (!Array.isArray(classes) || classes.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Liste de classes requise'
            });
        }
        
        // Marquer l'atelier comme obligatoire
        await query('UPDATE ateliers SET obligatoire = TRUE WHERE id = ?', [id]);
        
        // Ajouter les liaisons classe-atelier
        for (const classeId of classes) {
            await query(
                `INSERT IGNORE INTO ateliers_obligatoires (atelier_id, classe_id) VALUES (?, ?)`,
                [id, classeId]
            );
        }
        
        // Log
        await query(
            'INSERT INTO historique (utilisateur_id, action, table_cible, id_cible, details) VALUES (?, ?, ?, ?, ?)',
            [req.user.id, 'ATELIER_OBLIGATOIRE', 'ateliers', id, `Atelier obligatoire pour ${classes.length} classes`]
        );
        
        res.json({
            success: true,
            message: 'Atelier marqué comme obligatoire'
        });
        
    } catch (error) {
        console.error('Erreur atelier obligatoire:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la configuration'
        });
    }
});

/**
 * POST /api/admin/inscriptions-manuelles
 * Inscrire manuellement des élèves (ateliers obligatoires)
 */
router.post('/inscriptions-manuelles', async (req, res) => {
    try {
        const { atelier_id, classe_ids } = req.body;
        
        if (!atelier_id || !Array.isArray(classe_ids)) {
            return res.status(400).json({
                success: false,
                message: 'Atelier ID et classes requises'
            });
        }
        
        // Récupérer le planning de l'atelier
        const plannings = await query(
            'SELECT id FROM planning WHERE atelier_id = ?',
            [atelier_id]
        );
        
        if (plannings.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Atelier non placé dans le planning'
            });
        }
        
        const planningId = plannings[0].id;
        
        let inscrit = 0;
        let errors = [];
        
        // Pour chaque classe
        for (const classeId of classe_ids) {
            // Récupérer tous les élèves de la classe
            const eleves = await query(
                'SELECT id FROM eleves WHERE classe_id = ?',
                [classeId]
            );
            
            // Inscrire chaque élève
            for (const eleve of eleves) {
                try {
                    // Vérifier si pas déjà inscrit
                    const existing = await query(
                        'SELECT id FROM inscriptions WHERE eleve_id = ? AND atelier_id = ? AND statut != "annulee"',
                        [eleve.id, atelier_id]
                    );
                    
                    if (existing.length === 0) {
                        await query(
                            `INSERT INTO inscriptions (eleve_id, atelier_id, planning_id, statut, inscription_manuelle)
                             VALUES (?, ?, ?, 'confirmee', TRUE)`,
                            [eleve.id, atelier_id, planningId]
                        );
                        inscrit++;
                    }
                } catch (error) {
                    errors.push({ eleve_id: eleve.id, error: error.message });
                }
            }
        }
        
        // Log
        await query(
            'INSERT INTO historique (utilisateur_id, action, details) VALUES (?, ?, ?)',
            [req.user.id, 'INSCRIPTIONS_MANUELLES', `${inscrit} élèves inscrits manuellement`]
        );
        
        res.json({
            success: true,
            message: `${inscrit} élèves inscrits`,
            data: { inscrit, errors }
        });
        
    } catch (error) {
        console.error('Erreur inscriptions manuelles:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors des inscriptions'
        });
    }
});

/**
 * GET /api/admin/listes/:atelierId
 * Liste des élèves inscrits à un atelier
 */
router.get('/listes/:atelierId', async (req, res) => {
    try {
        const { atelierId } = req.params;
        
        const eleves = await query(`
            SELECT 
                i.id as inscription_id,
                i.statut,
                i.inscription_manuelle,
                u.nom as eleve_nom,
                u.prenom as eleve_prenom,
                e.numero_eleve,
                c.nom as classe_nom
            FROM inscriptions i
            JOIN eleves e ON i.eleve_id = e.id
            JOIN utilisateurs u ON e.utilisateur_id = u.id
            JOIN classes c ON e.classe_id = c.id
            WHERE i.atelier_id = ? AND i.statut = 'confirmee'
            ORDER BY c.nom, u.nom, u.prenom
        `, [atelierId]);
        
        res.json({
            success: true,
            data: eleves
        });
        
    } catch (error) {
        console.error('Erreur liste élèves:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la récupération de la liste'
        });
    }
});

module.exports = router;
