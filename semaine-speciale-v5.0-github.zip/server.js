const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const { testConnection } = require('./config/database');
const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');
const enseignantsRoutes = require('./routes/enseignants');
const planningRoutes = require('./routes/planning');
const elevesRoutes = require('./routes/eleves');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir les fichiers statiques (interface web)
app.use(express.static('public'));

// Routes API
app.use('/api/auth', authRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/enseignants', enseignantsRoutes);
app.use('/api/planning', planningRoutes);
app.use('/api/eleves', elevesRoutes);

// Route de test
app.get('/api/health', (req, res) => {
    res.json({ 
        success: true, 
        message: 'Serveur opérationnel',
        timestamp: new Date().toISOString()
    });
});

// Route par défaut - redirection vers l'interface
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Gestion des erreurs 404
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: 'Route non trouvée'
    });
});

// Gestion globale des erreurs
app.use((err, req, res, next) => {
    console.error('Erreur serveur:', err);
    res.status(500).json({
        success: false,
        message: 'Erreur serveur interne',
        error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
});

// Démarrage du serveur
async function startServer() {
    try {
        // Test de connexion à la base de données
        const dbConnected = await testConnection();
        
        if (!dbConnected) {
            console.error('❌ Impossible de démarrer le serveur sans connexion à la base de données');
            console.error('Vérifiez votre fichier .env et votre installation MySQL');
            process.exit(1);
        }

        app.listen(PORT, () => {
            console.log('\n╔════════════════════════════════════════════════════════════╗');
            console.log('║   🎓 PLATEFORME SEMAINE SPÉCIALE - COLLÈGE TROIS-SAPINS   ║');
            console.log('╚════════════════════════════════════════════════════════════╝\n');
            console.log(`🚀 Serveur démarré sur le port ${PORT}`);
            console.log(`🌐 Interface web: http://localhost:${PORT}`);
            console.log(`📡 API disponible: http://localhost:${PORT}/api`);
            console.log(`📊 Environnement: ${process.env.NODE_ENV || 'development'}\n`);
        });

    } catch (error) {
        console.error('❌ Erreur au démarrage du serveur:', error);
        process.exit(1);
    }
}

// Gestion des arrêts propres
process.on('SIGTERM', () => {
    console.log('\n👋 Arrêt du serveur en cours...');
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('\n👋 Arrêt du serveur en cours...');
    process.exit(0);
});

// Démarrage
startServer();

module.exports = app;
