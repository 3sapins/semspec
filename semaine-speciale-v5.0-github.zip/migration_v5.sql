-- Migration v4.0 vers v5.0
-- À exécuter si vous avez déjà une base de données existante

-- Ajouter les colonnes pour enseignants 2 et 3
ALTER TABLE ateliers 
ADD COLUMN enseignant2_acronyme VARCHAR(10) DEFAULT NULL COMMENT 'Deuxième enseignant accompagnant' AFTER enseignant_acronyme,
ADD COLUMN enseignant3_acronyme VARCHAR(10) DEFAULT NULL COMMENT 'Troisième enseignant accompagnant' AFTER enseignant2_acronyme;

-- Ajouter les index
ALTER TABLE ateliers 
ADD INDEX idx_enseignant2 (enseignant2_acronyme),
ADD INDEX idx_enseignant3 (enseignant3_acronyme);

-- Ajouter la configuration quota places
INSERT IGNORE INTO configuration (cle, valeur, description, type) VALUES
('quota_places_pourcent', '100', 'Pourcentage de places disponibles (ouverture progressive)', 'number');

-- Mise à jour terminée
SELECT 'Migration v4.0 -> v5.0 terminée avec succès!' as message;
