# DOCUMENTATION - SCHÉMA BASE DE DONNÉES
## Plateforme Semaine Spéciale - Collège des Trois-Sapins

---

## 📊 STRUCTURE GÉNÉRALE

Le schéma comprend **15 tables principales** organisées en 5 catégories :

### 1. UTILISATEURS ET INFRASTRUCTURE (4 tables)
- `utilisateurs` : Tous les comptes (admin, enseignants, élèves)
- `classes` : Les 30 classes (9VP, 9VG, 10VP, 10VG, 11VP, 11VG, RAC)
- `eleves` : Données élèves liées aux utilisateurs et classes
- `salles` : Les 110 salles disponibles

### 2. CONFIGURATION TEMPORELLE (1 table)
- `creneaux` : Les 14 créneaux horaires de la semaine (Lun-Ven, hors Mer PM)

### 3. ATELIERS (2 tables)
- `ateliers` : Les ~200 ateliers créés par les enseignants
- `ateliers_obligatoires` : Liaison ateliers ↔ classes obligatoires

### 4. DISPONIBILITÉS ET PLANNING (2 tables)
- `disponibilites_enseignants` : Disponibilités des 120 enseignants par créneau
- `planning` : Attribution finale atelier → salle → créneaux

### 5. INSCRIPTIONS ÉLÈVES (2 tables)
- `inscriptions` : Inscriptions des 850 élèves aux ateliers
- `quotas_inscription` : Gestion de l'ouverture progressive par classe

### 6. SYSTÈME (2 tables + 3 vues)
- `configuration` : Paramètres globaux (budget max, dates, etc.)
- `historique` : Logs d'actions pour traçabilité

---

## 📋 TABLES DÉTAILLÉES

### `utilisateurs`
**Rôle :** Gestion centralisée de tous les comptes

| Champ | Type | Description |
|-------|------|-------------|
| `acronyme` | VARCHAR(10) | Identifiant unique (3 lettres majuscules) |
| `nom` | VARCHAR(100) | Nom de famille |
| `prenom` | VARCHAR(100) | Prénom |
| `email` | VARCHAR(150) | Email (unique, optionnel pour élèves) |
| `mot_de_passe` | VARCHAR(255) | Hash bcrypt du mot de passe |
| `role` | ENUM | 'admin', 'enseignant', 'eleve' |

**Points clés :**
- Un seul utilisateur peut avoir plusieurs rôles via des tables de liaison
- Authentification via acronyme + mot de passe
- Les élèves ont des comptes mais authentification simplifiée possible

---

### `classes`
**Rôle :** Structure des 30 classes de l'établissement

| Champ | Type | Description |
|-------|------|-------------|
| `nom` | VARCHAR(20) | Nom unique (ex: "9VP1", "11VG8", "RAC1") |
| `niveau` | VARCHAR(10) | "9", "10", "11", "RAC" |
| `voie` | ENUM | 'VP', 'VG', 'RAC' |
| `annee` | INT | Année scolaire (9, 10, 11) |
| `nombre_eleves` | INT | Mis à jour automatiquement par trigger |

**Points clés :**
- 14 classes VG, 14 classes VP, 2 classes RAC = 30 classes
- Le nombre d'élèves se calcule automatiquement

---

### `eleves`
**Rôle :** Liaison entre utilisateurs et classes, données spécifiques élèves

| Champ | Type | Description |
|-------|------|-------------|
| `utilisateur_id` | INT | Référence vers `utilisateurs` |
| `classe_id` | INT | Référence vers `classes` |
| `numero_eleve` | VARCHAR(20) | Numéro d'identification scolaire |

**Points clés :**
- Permet de retrouver rapidement tous les élèves d'une classe
- Facilite les inscriptions par classe

---

### `salles`
**Rôle :** Inventaire des 110 salles avec caractéristiques

| Champ | Type | Description |
|-------|------|-------------|
| `nom` | VARCHAR(50) | Nom unique (ex: "A201", "Gymnase", "Labo2") |
| `capacite` | INT | Nombre max d'élèves |
| `type_salle` | VARCHAR(50) | Type (ex: "classe", "labo", "gymnase") |
| `equipement` | TEXT | Équipements disponibles |
| `batiment` | VARCHAR(50) | Bâtiment de la salle |
| `disponible` | BOOLEAN | Si la salle est utilisable |

**Points clés :**
- Import CSV prévu pour remplissage initial
- Le type permet de faire correspondre avec les demandes des ateliers

---

### `creneaux`
**Rôle :** Les 14 créneaux de la semaine spéciale

| Champ | Type | Description |
|-------|------|-------------|
| `jour` | ENUM | 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi' |
| `periode` | VARCHAR(20) | "P1-2", "P3-4", "P6-7" |
| `heure_debut` | TIME | Heure de début |
| `heure_fin` | TIME | Heure de fin |
| `ordre` | INT | Ordre chronologique (1 à 14) |

**Points clés :**
- **14 créneaux** : Lun-Mar-Jeu-Ven = 3 créneaux × 4 = 12, Mer = 2 créneaux
- Permet la gestion des ateliers de 2, 4 ou 6 périodes
- L'ordre facilite le calcul des créneaux consécutifs

---

### `ateliers`
**Rôle :** Cœur du système - les ~200 ateliers proposés

| Champ | Type | Description |
|-------|------|-------------|
| `nom` | VARCHAR(200) | Titre de l'atelier |
| `description` | TEXT | Description complète |
| `enseignant_acronyme` | VARCHAR(10) | Responsable (ou "EXT") |
| `duree` | INT | 2, 4 ou 6 périodes |
| `nombre_places_max` | INT | Capacité maximale |
| `budget_max` | DECIMAL(10,2) | Budget en CHF si remplissage complet |
| `type_salle_demande` | VARCHAR(50) | Type de salle souhaité |
| `remarques` | TEXT | Notes internes |
| `informations_eleves` | TEXT | Info pour élèves inscrits (matériel, RDV) |
| `statut` | ENUM | 'brouillon', 'soumis', 'valide', 'refuse', 'annule' |
| `obligatoire` | BOOLEAN | Si atelier obligatoire pour classe(s) |

**Points clés :**
- Les enseignants créent en "brouillon" puis soumettent
- Admin valide/refuse
- Le budget s'additionne pour contrôle global (max 10'000 CHF)
- Durée en périodes : 2 = 1 créneau, 4 = 2 créneaux, 6 = 3 créneaux

---

### `ateliers_obligatoires`
**Rôle :** Gestion des ateliers imposés à certaines classes

| Champ | Type | Description |
|-------|------|-------------|
| `atelier_id` | INT | Référence atelier |
| `classe_id` | INT | Référence classe |

**Points clés :**
- Un atelier peut être obligatoire pour plusieurs classes
- Les élèves de ces classes seront inscrits manuellement par admin
- Ces inscriptions court-circuitent le système de quotas

---

### `disponibilites_enseignants`
**Rôle :** Disponibilités des 120 enseignants pour chaque créneau

| Champ | Type | Description |
|-------|------|-------------|
| `enseignant_acronyme` | VARCHAR(10) | Enseignant concerné |
| `creneau_id` | INT | Créneau concerné (1 à 14) |
| `disponible` | BOOLEAN | Si dispo pour animer un atelier |
| `periodes_enseignees_normalement` | INT | Charge normale sur ce créneau |

**Points clés :**
- Chaque enseignant coche ses 14 créneaux
- Permet de voir leur charge de travail normale
- L'algorithme d'allocation tiendra compte de ces dispo

---

### `planning`
**Rôle :** Attribution finale des ateliers dans le temps et l'espace

| Champ | Type | Description |
|-------|------|-------------|
| `atelier_id` | INT | Atelier planifié |
| `salle_id` | INT | Salle attribuée |
| `creneau_debut_id` | INT | Premier créneau utilisé |
| `nombre_creneaux` | INT | Nombre de créneaux consécutifs (1, 2 ou 3) |
| `valide` | BOOLEAN | Si l'allocation est confirmée |

**Points clés :**
- C'est cette table qui crée le planning final
- Un atelier de 6 périodes occupe 3 créneaux consécutifs
- L'algorithme d'allocation remplit cette table
- Admin peut modifier manuellement

---

### `inscriptions`
**Rôle :** Inscriptions des 850 élèves aux ateliers

| Champ | Type | Description |
|-------|------|-------------|
| `eleve_id` | INT | Élève inscrit |
| `atelier_id` | INT | Atelier choisi |
| `planning_id` | INT | Référence vers le planning (si atelier placé) |
| `statut` | ENUM | 'en_attente', 'confirmee', 'annulee' |
| `inscription_manuelle` | BOOLEAN | Si fait par admin (ateliers obligatoires) |

**Points clés :**
- Un élève peut s'inscrire à plusieurs ateliers sur créneaux différents
- Les ateliers obligatoires sont marqués comme inscription manuelle
- Le statut permet de gérer les listes d'attente

---

### `quotas_inscription`
**Rôle :** Ouverture progressive des inscriptions par classe

| Champ | Type | Description |
|-------|------|-------------|
| `classe_id` | INT | Classe concernée |
| `date_ouverture` | DATETIME | Moment d'ouverture des inscriptions |
| `places_disponibles` | INT | Quota de places réservées |
| `actif` | BOOLEAN | Si le quota est actif |

**Points clés :**
- Permet d'ouvrir les inscriptions classe par classe
- Évite la ruée et permet une répartition équitable
- Admin peut ajuster les quotas en temps réel

---

### `configuration`
**Rôle :** Paramètres globaux de l'application

| Champ | Type | Valeur par défaut |
|-------|------|-------------------|
| `budget_max_global` | number | 10000 CHF |
| `inscriptions_ouvertes` | boolean | false |
| `date_debut_semaine` | date | NULL (à définir) |
| `date_fin_semaine` | date | NULL (à définir) |
| `nom_evenement` | text | "Semaine Spéciale" |
| `annee_scolaire` | text | "2025-2026" |

**Points clés :**
- Admin peut modifier ces valeurs via l'interface
- Le budget max est contrôlé en temps réel

---

### `historique`
**Rôle :** Traçabilité de toutes les actions importantes

| Champ | Type | Description |
|-------|------|-------------|
| `utilisateur_id` | INT | Qui a fait l'action |
| `action` | VARCHAR(100) | Type d'action (CREATE, UPDATE, DELETE, etc.) |
| `table_cible` | VARCHAR(50) | Table modifiée |
| `id_cible` | INT | ID de l'enregistrement modifié |
| `details` | TEXT | Détails de l'action |
| `date_action` | TIMESTAMP | Quand |

**Points clés :**
- Permet de voir qui a créé/modifié/supprimé quoi
- Utile pour résoudre les conflits
- Génération automatique via triggers

---

## 🔍 VUES SQL

### `vue_ateliers_complet`
Récapitulatif enrichi de chaque atelier :
- Nombre d'inscrits actuels
- Places restantes
- Classes pour lesquelles c'est obligatoire

### `vue_planning_complet`
Planning détaillé avec :
- Informations atelier
- Salle et capacité
- Jour/période/horaires
- Nombre d'inscrits

### `vue_stats_classes`
Statistiques par classe :
- Nombre total d'élèves
- Nombre d'élèves ayant fait au moins une inscription
- Nombre total d'inscriptions

---

## 🔐 SÉCURITÉ

### Contraintes d'intégrité
- Clés étrangères avec `ON DELETE CASCADE` ou `ON DELETE SET NULL`
- Index uniques sur identifiants critiques (acronyme, email, nom classe)
- Contraintes UNIQUE sur combinaisons (ex: enseignant + créneau)

### Triggers automatiques
1. **Mise à jour du nombre d'élèves** : Quand un élève est ajouté à une classe
2. **Log des modifications d'ateliers** : Trace les changements de statut

---

## 📊 VOLUMÉTRIE ATTENDUE

| Table | Nombre d'enregistrements |
|-------|--------------------------|
| utilisateurs | ~970 (120 enseignants + 850 élèves + admins) |
| classes | 30 |
| eleves | 850 |
| salles | 110 |
| creneaux | 14 |
| ateliers | ~200 |
| ateliers_obligatoires | ~50 (estimé) |
| disponibilites_enseignants | ~1680 (120 × 14) |
| planning | ~200 (un par atelier) |
| inscriptions | ~2000-3000 (plusieurs par élève) |
| quotas_inscription | ~30 (un par classe) |
| configuration | ~10 |
| historique | Croissant (plusieurs milliers sur l'année) |

**Total estimé :** ~7000 enregistrements + historique

---

## 🚀 PROCHAINES ÉTAPES

1. ✅ Schéma validé
2. ⏳ Scripts d'import CSV (salles, enseignants, élèves)
3. ⏳ Backend API (Node.js + Express)
4. ⏳ Interface Admin
5. ⏳ Interface Enseignants
6. ⏳ Interface Élèves
7. ⏳ Algorithme d'allocation
8. ⏳ Outils d'export et rapports

---

## 📝 NOTES IMPORTANTES

### Durées des ateliers
- **2 périodes** = 1 créneau (ex: P1-2)
- **4 périodes** = 2 créneaux consécutifs (ex: P1-2 + P3-4)
- **6 périodes** = 3 créneaux consécutifs (ex: P1-2 + P3-4 + P6-7 = journée complète)

### Contraintes mercredi
- Seulement 2 créneaux disponibles (matin)
- Les ateliers de 6 périodes ne peuvent PAS être placés le mercredi

### Gestion du budget
- Budget max global : 10'000 CHF (modifiable)
- Calcul automatique de la somme des budgets des ateliers validés
- Alerte si dépassement
- Admin doit refuser/annuler des ateliers pour respecter le budget

---

*Document généré le 15 janvier 2026*
*Collège des Trois-Sapins - Echallens, Suisse*
