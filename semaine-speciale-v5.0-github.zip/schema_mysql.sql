-- ============================================
-- SCHÉMA MYSQL - PLATEFORME SEMAINE SPÉCIALE
-- Collège des Trois-Sapins - Echallens
-- ============================================

-- Création de la base de données
CREATE DATABASE IF NOT EXISTS semaine_speciale CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE semaine_speciale;

-- ============================================
-- TABLES DE BASE - UTILISATEURS ET INFRASTRUCTURE
-- ============================================

-- Table des utilisateurs (enseignants, admin, élèves)
CREATE TABLE utilisateurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    acronyme VARCHAR(10) UNIQUE NOT NULL,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    role ENUM('admin', 'enseignant', 'eleve') NOT NULL DEFAULT 'enseignant',
    actif BOOLEAN DEFAULT TRUE,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    derniere_connexion TIMESTAMP NULL,
    INDEX idx_acronyme (acronyme),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des classes
CREATE TABLE classes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(20) UNIQUE NOT NULL,
    niveau VARCHAR(10) NOT NULL,
    voie ENUM('VP', 'VG', 'RAC') NOT NULL,
    annee INT NOT NULL,
    nombre_eleves INT DEFAULT 0,
    INDEX idx_nom (nom)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des élèves (liée aux utilisateurs et classes)
CREATE TABLE eleves (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT NOT NULL,
    classe_id INT NOT NULL,
    numero_eleve VARCHAR(20),
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    FOREIGN KEY (classe_id) REFERENCES classes(id) ON DELETE CASCADE,
    INDEX idx_classe (classe_id),
    INDEX idx_utilisateur (utilisateur_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des salles
CREATE TABLE salles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(50) UNIQUE NOT NULL,
    capacite INT NOT NULL DEFAULT 25,
    type_salle VARCHAR(50),
    equipement TEXT,
    batiment VARCHAR(50),
    etage VARCHAR(10),
    disponible BOOLEAN DEFAULT TRUE,
    INDEX idx_nom (nom),
    INDEX idx_type (type_salle)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLES DE CONFIGURATION TEMPORELLE
-- ============================================

-- Table des créneaux horaires
CREATE TABLE creneaux (
    id INT AUTO_INCREMENT PRIMARY KEY,
    jour ENUM('lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi') NOT NULL,
    periode VARCHAR(20) NOT NULL,
    heure_debut TIME NOT NULL,
    heure_fin TIME NOT NULL,
    ordre INT NOT NULL,
    actif BOOLEAN DEFAULT TRUE,
    INDEX idx_jour (jour),
    INDEX idx_ordre (ordre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLES DES ATELIERS
-- ============================================

-- Table des ateliers
CREATE TABLE ateliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(200) NOT NULL,
    description TEXT,
    enseignant_acronyme VARCHAR(10) NOT NULL,
    enseignant2_acronyme VARCHAR(10) DEFAULT NULL COMMENT 'Deuxième enseignant accompagnant',
    enseignant3_acronyme VARCHAR(10) DEFAULT NULL COMMENT 'Troisième enseignant accompagnant',
    duree INT NOT NULL COMMENT 'En nombre de périodes: 2, 4 ou 6',
    nombre_places_max INT NOT NULL,
    budget_max DECIMAL(10,2) DEFAULT 0.00,
    type_salle_demande VARCHAR(50),
    remarques TEXT,
    informations_eleves TEXT COMMENT 'Matériel, lieu de RDV, etc.',
    statut ENUM('brouillon', 'soumis', 'valide', 'refuse', 'annule') DEFAULT 'brouillon',
    obligatoire BOOLEAN DEFAULT FALSE COMMENT 'Si atelier obligatoire pour certaines classes',
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_modification TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_enseignant (enseignant_acronyme),
    INDEX idx_enseignant2 (enseignant2_acronyme),
    INDEX idx_enseignant3 (enseignant3_acronyme),
    INDEX idx_statut (statut),
    INDEX idx_duree (duree)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des ateliers obligatoires par classe
CREATE TABLE ateliers_obligatoires (
    id INT AUTO_INCREMENT PRIMARY KEY,
    atelier_id INT NOT NULL,
    classe_id INT NOT NULL,
    FOREIGN KEY (atelier_id) REFERENCES ateliers(id) ON DELETE CASCADE,
    FOREIGN KEY (classe_id) REFERENCES classes(id) ON DELETE CASCADE,
    UNIQUE KEY unique_atelier_classe (atelier_id, classe_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLES DE DISPONIBILITÉS ENSEIGNANTS
-- ============================================

-- Table des disponibilités enseignants
CREATE TABLE disponibilites_enseignants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    enseignant_acronyme VARCHAR(10) NOT NULL,
    creneau_id INT NOT NULL,
    disponible BOOLEAN DEFAULT TRUE,
    periodes_enseignees_normalement INT DEFAULT 0 COMMENT 'Nombre de périodes normalement enseignées sur ce créneau',
    FOREIGN KEY (creneau_id) REFERENCES creneaux(id) ON DELETE CASCADE,
    UNIQUE KEY unique_enseignant_creneau (enseignant_acronyme, creneau_id),
    INDEX idx_enseignant (enseignant_acronyme)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLES DE PLANNING ET ALLOCATION
-- ============================================

-- Table du planning final (allocation des ateliers)
CREATE TABLE planning (
    id INT AUTO_INCREMENT PRIMARY KEY,
    atelier_id INT NOT NULL,
    salle_id INT,
    creneau_debut_id INT NOT NULL COMMENT 'Premier créneau de l''atelier',
    nombre_creneaux INT NOT NULL COMMENT 'Nombre de créneaux consécutifs',
    valide BOOLEAN DEFAULT FALSE,
    date_allocation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (atelier_id) REFERENCES ateliers(id) ON DELETE CASCADE,
    FOREIGN KEY (salle_id) REFERENCES salles(id) ON DELETE SET NULL,
    FOREIGN KEY (creneau_debut_id) REFERENCES creneaux(id) ON DELETE CASCADE,
    INDEX idx_atelier (atelier_id),
    INDEX idx_salle (salle_id),
    INDEX idx_creneau (creneau_debut_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLES D'INSCRIPTIONS ÉLÈVES
-- ============================================

-- Table des inscriptions élèves
CREATE TABLE inscriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    eleve_id INT NOT NULL,
    atelier_id INT NOT NULL,
    planning_id INT,
    date_inscription TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    statut ENUM('en_attente', 'confirmee', 'annulee') DEFAULT 'en_attente',
    inscription_manuelle BOOLEAN DEFAULT FALSE COMMENT 'Inscription faite par admin pour atelier obligatoire',
    FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE CASCADE,
    FOREIGN KEY (atelier_id) REFERENCES ateliers(id) ON DELETE CASCADE,
    FOREIGN KEY (planning_id) REFERENCES planning(id) ON DELETE SET NULL,
    INDEX idx_eleve (eleve_id),
    INDEX idx_atelier (atelier_id),
    INDEX idx_statut (statut)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des quotas d'inscription par classe
CREATE TABLE quotas_inscription (
    id INT AUTO_INCREMENT PRIMARY KEY,
    classe_id INT NOT NULL,
    date_ouverture DATETIME NOT NULL,
    places_disponibles INT NOT NULL COMMENT 'Nombre de places réservées à cette classe',
    actif BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (classe_id) REFERENCES classes(id) ON DELETE CASCADE,
    INDEX idx_classe (classe_id),
    INDEX idx_date_ouverture (date_ouverture)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLES DE CONFIGURATION SYSTÈME
-- ============================================

-- Table de configuration générale
CREATE TABLE configuration (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cle VARCHAR(100) UNIQUE NOT NULL,
    valeur TEXT,
    description TEXT,
    type ENUM('text', 'number', 'boolean', 'date') DEFAULT 'text',
    date_modification TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table d'historique des actions (logs)
CREATE TABLE historique (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT,
    action VARCHAR(100) NOT NULL,
    table_cible VARCHAR(50),
    id_cible INT,
    details TEXT,
    date_action TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE SET NULL,
    INDEX idx_utilisateur (utilisateur_id),
    INDEX idx_date (date_action),
    INDEX idx_action (action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- INSERTION DES DONNÉES INITIALES
-- ============================================

-- Insertion des créneaux horaires standard
INSERT INTO creneaux (jour, periode, heure_debut, heure_fin, ordre, actif) VALUES
-- Lundi
('lundi', 'P1-2', '08:00:00', '09:35:00', 1, TRUE),
('lundi', 'P3-4', '09:50:00', '11:25:00', 2, TRUE),
('lundi', 'P6-7', '13:30:00', '15:05:00', 3, TRUE),
-- Mardi
('mardi', 'P1-2', '08:00:00', '09:35:00', 4, TRUE),
('mardi', 'P3-4', '09:50:00', '11:25:00', 5, TRUE),
('mardi', 'P6-7', '13:30:00', '15:05:00', 6, TRUE),
-- Mercredi (seulement matin)
('mercredi', 'P1-2', '08:00:00', '09:35:00', 7, TRUE),
('mercredi', 'P3-4', '09:50:00', '11:25:00', 8, TRUE),
-- Jeudi
('jeudi', 'P1-2', '08:00:00', '09:35:00', 9, TRUE),
('jeudi', 'P3-4', '09:50:00', '11:25:00', 10, TRUE),
('jeudi', 'P6-7', '13:30:00', '15:05:00', 11, TRUE),
-- Vendredi
('vendredi', 'P1-2', '08:00:00', '09:35:00', 12, TRUE),
('vendredi', 'P3-4', '09:50:00', '11:25:00', 13, TRUE),
('vendredi', 'P6-7', '13:30:00', '15:05:00', 14, TRUE);

-- Insertion des classes
INSERT INTO classes (nom, niveau, voie, annee) VALUES
('9VP1', '9', 'VP', 9),
('9VP2', '9', 'VP', 9),
('9VP3', '9', 'VP', 9),
('9VP4', '9', 'VP', 9),
('9VP5', '9', 'VP', 9),
('9VP6', '9', 'VP', 9),
('9VG1', '9', 'VG', 9),
('9VG2', '9', 'VG', 9),
('9VG3', '9', 'VG', 9),
('9VG4', '9', 'VG', 9),
('9VG5', '9', 'VG', 9),
('9VG6', '9', 'VG', 9),
('9VG7', '9', 'VG', 9),
('9VG8', '9', 'VG', 9),
('10VP1', '10', 'VP', 10),
('10VP2', '10', 'VP', 10),
('10VP3', '10', 'VP', 10),
('10VP4', '10', 'VP', 10),
('10VP5', '10', 'VP', 10),
('10VP6', '10', 'VP', 10),
('10VG1', '10', 'VG', 10),
('10VG2', '10', 'VG', 10),
('10VG3', '10', 'VG', 10),
('10VG4', '10', 'VG', 10),
('10VG5', '10', 'VG', 10),
('10VG6', '10', 'VG', 10),
('10VG7', '10', 'VG', 10),
('10VG8', '10', 'VG', 10),
('11VP1', '11', 'VP', 11),
('11VP2', '11', 'VP', 11),
('11VP3', '11', 'VP', 11),
('11VP4', '11', 'VP', 11),
('11VP5', '11', 'VP', 11),
('11VP6', '11', 'VP', 11),
('11VG1', '11', 'VG', 11),
('11VG2', '11', 'VG', 11),
('11VG3', '11', 'VG', 11),
('11VG4', '11', 'VG', 11),
('11VG5', '11', 'VG', 11),
('11VG6', '11', 'VG', 11),
('11VG7', '11', 'VG', 11),
('11VG8', '11', 'VG', 11),
('RAC1', 'RAC', 'RAC', 11),
('RAC2', 'RAC', 'RAC', 11);

-- Insertion des configurations par défaut
INSERT INTO configuration (cle, valeur, description, type) VALUES
('budget_max_global', '10000', 'Budget maximum total en CHF', 'number'),
('inscriptions_ouvertes', 'false', 'Inscriptions élèves ouvertes ou fermées', 'boolean'),
('quota_places_pourcent', '100', 'Pourcentage de places disponibles (ouverture progressive)', 'number'),
('date_debut_semaine', NULL, 'Date de début de la semaine spéciale', 'date'),
('date_fin_semaine', NULL, 'Date de fin de la semaine spéciale', 'date'),
('nom_evenement', 'Semaine Spéciale', 'Nom de l\'événement', 'text'),
('annee_scolaire', '2025-2026', 'Année scolaire concernée', 'text');

-- Création d'un compte admin par défaut (mot de passe: admin123 - À CHANGER!)
-- Note: Le hash doit être généré côté application avec bcrypt
INSERT INTO utilisateurs (acronyme, nom, prenom, email, mot_de_passe, role) VALUES
('ADM', 'Administrateur', 'Système', 'admin@trois-sapins.ch', '$2b$10$placeholder', 'admin');

-- ============================================
-- VUES UTILES POUR REQUÊTES FRÉQUENTES
-- ============================================

-- Vue: Récapitulatif des ateliers avec infos enseignant
CREATE VIEW vue_ateliers_complet AS
SELECT 
    a.*,
    COUNT(DISTINCT i.id) as nombre_inscrits,
    (a.nombre_places_max - COUNT(DISTINCT i.id)) as places_restantes,
    GROUP_CONCAT(DISTINCT c.nom ORDER BY c.nom SEPARATOR ', ') as classes_obligatoires
FROM ateliers a
LEFT JOIN inscriptions i ON a.id = i.atelier_id AND i.statut = 'confirmee'
LEFT JOIN ateliers_obligatoires ao ON a.id = ao.atelier_id
LEFT JOIN classes c ON ao.classe_id = c.id
GROUP BY a.id;

-- Vue: Planning avec détails
CREATE VIEW vue_planning_complet AS
SELECT 
    p.*,
    a.nom as atelier_nom,
    a.enseignant_acronyme,
    s.nom as salle_nom,
    s.capacite as salle_capacite,
    cr.jour,
    cr.periode,
    cr.heure_debut,
    cr.heure_fin,
    COUNT(DISTINCT i.id) as nombre_inscrits
FROM planning p
JOIN ateliers a ON p.atelier_id = a.id
LEFT JOIN salles s ON p.salle_id = s.id
JOIN creneaux cr ON p.creneau_debut_id = cr.id
LEFT JOIN inscriptions i ON p.id = i.planning_id AND i.statut = 'confirmee'
GROUP BY p.id;

-- Vue: Statistiques par classe
CREATE VIEW vue_stats_classes AS
SELECT 
    c.nom as classe,
    c.nombre_eleves,
    COUNT(DISTINCT e.id) as nombre_eleves_inscrits,
    COUNT(DISTINCT i.id) as nombre_inscriptions
FROM classes c
LEFT JOIN eleves e ON c.id = e.classe_id
LEFT JOIN inscriptions i ON e.id = i.eleve_id AND i.statut = 'confirmee'
GROUP BY c.id;

-- ============================================
-- INDEX SUPPLÉMENTAIRES POUR PERFORMANCES
-- ============================================

-- Index composites pour requêtes fréquentes
CREATE INDEX idx_inscriptions_eleve_statut ON inscriptions(eleve_id, statut);
CREATE INDEX idx_inscriptions_atelier_statut ON inscriptions(atelier_id, statut);
CREATE INDEX idx_planning_salle_creneau ON planning(salle_id, creneau_debut_id);
CREATE INDEX idx_ateliers_statut_enseignant ON ateliers(statut, enseignant_acronyme);

-- ============================================
-- TRIGGERS POUR AUTOMATISATION
-- ============================================

-- Trigger: Mise à jour du nombre d'élèves dans une classe
DELIMITER //
CREATE TRIGGER update_nombre_eleves_classe
AFTER INSERT ON eleves
FOR EACH ROW
BEGIN
    UPDATE classes 
    SET nombre_eleves = (SELECT COUNT(*) FROM eleves WHERE classe_id = NEW.classe_id)
    WHERE id = NEW.classe_id;
END//
DELIMITER ;

-- Trigger: Log des modifications d'ateliers
DELIMITER //
CREATE TRIGGER log_modification_atelier
AFTER UPDATE ON ateliers
FOR EACH ROW
BEGIN
    INSERT INTO historique (utilisateur_id, action, table_cible, id_cible, details)
    VALUES (NULL, 'UPDATE', 'ateliers', NEW.id, CONCAT('Statut changé de ', OLD.statut, ' à ', NEW.statut));
END//
DELIMITER ;

-- ============================================
-- FIN DU SCHÉMA
-- ============================================
