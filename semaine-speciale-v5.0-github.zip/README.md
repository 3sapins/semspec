# 🎓 Semaine Spéciale - Plateforme de Gestion

> Système complet de gestion de semaine spéciale pour établissements scolaires

![Version](https://img.shields.io/badge/version-5.0-blue)
![Node](https://img.shields.io/badge/node-%3E%3D18.0.0-green)
![License](https://img.shields.io/badge/license-MIT-green)

## ✨ Fonctionnalités

### 🎯 Pour les Enseignants
- ✅ Création et gestion d'ateliers
- ✅ Déclaration des disponibilités
- ✅ Multi-enseignants (jusqu'à 3 par atelier)
- ✅ Suivi des inscriptions

### 👨‍🎓 Pour les Élèves
- ✅ Inscription aux ateliers
- ✅ Visualisation du planning personnalisé
- ✅ Gestion des conflits horaires
- ✅ Quota progressif des places

### 🛠️ Pour les Administrateurs
- ✅ Validation des ateliers
- ✅ Algorithme d'allocation automatique
- ✅ Planning multi-vues (salles, enseignants)
- ✅ Gestion complète (utilisateurs, salles, classes)
- ✅ Inscriptions manuelles
- ✅ Quota de places configurable
- ✅ Placement manuel d'ateliers
- ✅ Gestion piquet et dégagement

## 🚀 Test Rapide sur Codespaces

### Lancer directement

1. Clique sur **"Code"** (bouton vert) → **"Codespaces"** → **"Create codespace"**
2. Attends que Codespaces démarre
3. Dans le terminal :

```bash
# Démarrer MySQL
sudo service mysql start

# Configuration
cp .env.example .env

# Installation
npm install
npm run init-db

# Lancement
npm start
```

4. Ouvre le port 3000 (popup automatique)
5. **Teste l'application !** 🎉

### Identifiants par défaut

- **Admin** : `ADM` / `admin123`
- **Enseignant** : `DUP` / `SemaineSpeciale2026`
- **Élève** : voir CSV d'exemple / `eleve2026`

---

## 📥 Installation Locale

### Prérequis
- Node.js 18+
- MySQL 8.0+

### Installation

```bash
git clone https://github.com/VOTRE-USERNAME/semaine-speciale.git
cd semaine-speciale

cp .env.example .env
# Éditer .env avec vos paramètres MySQL

npm install
npm run init-db
npm start
```

**Accès** : http://localhost:3000

---

## 📊 Capacités

- **850 élèves** / 30 classes
- **120 enseignants**
- **200+ ateliers**
- **14 créneaux** sur 5 jours
- **110 salles**

---

## 🎯 Nouveautés v5.0

- ✨ Quota progressif des places
- ✨ Multi-enseignants (3 max)
- ✨ Planning multi-vues
- ✨ Inscriptions manuelles en masse
- ✨ Gestion piquet/dégagement

Voir [MODIFICATIONS_V5.pdf](docs/MODIFICATIONS_V5.pdf) pour tous les détails.

---

## 📚 Documentation

- [INSTALLATION_V5.pdf](docs/INSTALLATION_V5.pdf) - Guide complet
- [MODIFICATIONS_V5.pdf](docs/MODIFICATIONS_V5.pdf) - Détails techniques
- [DOCUMENTATION_SCHEMA.md](DOCUMENTATION_SCHEMA.md) - Base de données

---

## 🗄️ Architecture

**Backend** : Node.js + Express + MySQL  
**Frontend** : HTML/CSS/JS vanilla  
**Auth** : JWT + bcrypt  
**15 tables** + API RESTful complète

---

## 📄 License

MIT License

---

**Développé pour le Collège des Trois-Sapins, Echallens 🇨🇭**

Version 5.0 - Janvier 2026
