const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const fs = require('fs').promises;
const path = require('path');
require('dotenv').config();

async function initDatabase() {
    let connection;
    
    try {
        console.log('🔧 Initialisation de la base de données...\n');
        
        // Connexion sans base de données spécifique
        connection = await mysql.createConnection({
            host: process.env.DB_HOST || 'localhost',
            port: process.env.DB_PORT || 3306,
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASSWORD || '',
            multipleStatements: true
        });
        
        console.log('✅ Connexion MySQL établie');
        
        // Lecture du fichier SQL
        const sqlPath = path.join(__dirname, '..', 'schema_mysql.sql');
        const sqlContent = await fs.readFile(sqlPath, 'utf-8');
        
        console.log('📄 Fichier schema_mysql.sql chargé');
        
        // Exécution du schéma SQL
        console.log('⚙️  Exécution du schéma SQL...');
        await connection.query(sqlContent);
        
        console.log('✅ Schéma créé avec succès');
        
        // Création du compte admin avec mot de passe hashé
        const adminPassword = await bcrypt.hash(
            process.env.ADMIN_PASSWORD || 'admin123',
            10
        );
        
        await connection.query(`
            USE ${process.env.DB_NAME || 'semaine_speciale'};
            UPDATE utilisateurs 
            SET mot_de_passe = '${adminPassword}',
                email = '${process.env.ADMIN_EMAIL || 'admin@trois-sapins.ch'}'
            WHERE acronyme = '${process.env.ADMIN_ACRONYME || 'ADM'}';
        `);
        
        console.log('✅ Compte administrateur créé');
        console.log(`   Acronyme: ${process.env.ADMIN_ACRONYME || 'ADM'}`);
        console.log(`   Mot de passe: ${process.env.ADMIN_PASSWORD || 'admin123'}`);
        console.log(`   ⚠️  PENSEZ À CHANGER LE MOT DE PASSE ADMIN!\n`);
        
        console.log('╔════════════════════════════════════════════════════╗');
        console.log('║   ✅ BASE DE DONNÉES INITIALISÉE AVEC SUCCÈS      ║');
        console.log('╚════════════════════════════════════════════════════╝\n');
        console.log('Vous pouvez maintenant:');
        console.log('1. Démarrer le serveur: npm start');
        console.log('2. Accéder à l\'interface: http://localhost:3000');
        console.log('3. Vous connecter avec le compte admin\n');
        
    } catch (error) {
        console.error('❌ Erreur lors de l\'initialisation:', error.message);
        process.exit(1);
    } finally {
        if (connection) {
            await connection.end();
        }
    }
}

// Exécution
initDatabase();
